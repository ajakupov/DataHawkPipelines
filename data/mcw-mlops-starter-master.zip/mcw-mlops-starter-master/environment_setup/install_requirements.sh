python --version
pip install azure-cli==2.11.1
pip install azureml-sdk==1.15.0
pip install azureml-dataprep[pandas]
